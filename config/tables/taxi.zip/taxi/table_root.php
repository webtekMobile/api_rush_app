<?php

$default_database = 'aaracgzs_ezy1';

$tables['taxi_inner_category']="{$default_database}.view_inner_category";
$tables['taxi_left_category']="{$default_database}.view_left_category";
$tables['taxi_vendor']="{$default_database}.tbl_vendor";










